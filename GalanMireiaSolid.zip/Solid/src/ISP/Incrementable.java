package ISP;

public interface Incrementable {
	public double getIncrementByYear(double years, double afection) ;

}
