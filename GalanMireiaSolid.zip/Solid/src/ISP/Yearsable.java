package ISP;

public interface Yearsable {
	public int getYears();
}
