package ISP;

import java.util.Map;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Pertsona mireia = new Pertsona("Mireia",22);
		
		
		System.out.println(mireia.calcCovid19Impact());
	
		
	

	
		
		
		

	}

}
