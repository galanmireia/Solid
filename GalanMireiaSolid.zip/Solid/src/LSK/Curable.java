package LSK;

public interface Curable {

	public void cure() ;
		
	
}
